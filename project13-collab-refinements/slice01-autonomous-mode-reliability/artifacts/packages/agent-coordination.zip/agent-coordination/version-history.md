# Agent Coordination Version History

## Version 2.0.0 - 2026-10-19

Require Operator-approved role/model/settings and expenditure scope before Autonomous contributor dispatch. Default to one implementer and independent reviewer, justify extra contexts and hold unavailable/unapproved configurations. Make stable worktree mutation/index ownership and attributable durable returns explicit. The dispatch approval gate changes the prior contract; ordinary lookup boundaries and independent repair review remain intact.

## Version 1.3.0 - 2026-10-18

Added an explicitly authorized Autonomous Mode exception to lookup-only
delegation, with contributor context packets, implementation/review ownership,
source-grounded integration and independent acceptance. Preserved ordinary
delegation defaults.

## Version 1.2.0 - 2026-09-17

Routed contributor terminology and workflow selection to the methodology.
Distinguished sustained, Operator-assigned CDC/CRC/CC contexts from ad hoc
lookup subagents. The optional CRC role and explicit design handoffs do not
authorize outsourcing judgment, changing architecture, or implicit enablement.
Recognized explicit one-contributor selection without simulated roles or
automatic delegation.

## Version 1.1.1 - 2026-09-06

Placed the skill version inside entrypoint metadata for compatibility with the skill-creator frontmatter validator.

Updated the component entrypoint to reflect that agent-coordination now ships
both inside `collaboration-framework.zip` and as standalone
`agent-coordination.zip`.

## Version 1.1.0 - 2026-09-05

Split the former SUBAGENT-DELEGATION-POLICY guide into four focused guides:
`01-when-to-delegate.md`, `02-context-packets.md`,
`03-result-integration.md`, and `04-anti-patterns.md`. The old
SUBAGENT-DELEGATION-POLICY path was moved with Git history to
`01-when-to-delegate.md` and is no longer a live route or package entry.

## Version 1.0.1 - 2026-09-04

Seeded the sibling component history for Arc08 Slice05. The component initially
routed to the former delegation-policy guide; broader guide decomposition into
delegation, context packets, result integration, and anti-patterns remained
deferred for operator review.

Future changes to `SKILL.md`, `guides/`, `templates/`, or `examples/` for this
component should be recorded here.

## Version 1.0.0 - 2026-09-04

Initial framework component entrypoint for agent coordination, created during
the Project04 framework component breakout from the former subagent delegation
policy surface. The component preserves the delegation policy as the current
guide while adopting the broader accepted component name.
