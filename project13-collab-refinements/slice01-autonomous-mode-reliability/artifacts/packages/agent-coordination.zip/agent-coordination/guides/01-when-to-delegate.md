# When To Delegate

Use this guide when deciding whether a task belongs in the main context, a
parallel lookup, or a delegated subagent. It preserves the original
thinking-versus-lookup policy while making the decision rule independently
loadable.

For self-contained handoff material, load
[`02-context-packets.md`](./02-context-packets.md). For integrating returned
evidence, load [`03-result-integration.md`](./03-result-integration.md). For
failure modes, load [`04-anti-patterns.md`](./04-anti-patterns.md).

## Autonomous Mode exception

The ordinary lookup-only policy below remains the default. In explicitly
Operator-authorized [Autonomous Mode](../../engineering-methods/guides/01-engineering-methodology.md#autonomous-mode),
CDC may instead assign bounded implementation and independent review to fully
briefed contributor subagents, with CRC when useful. These contexts own their
assigned implementation or verification judgment; CDC owns integrated design,
source-grounded reconciliation and follow-through. This permission depends on
the recorded mode and scope, not on task size or available tools.

Use [contributor packets](./02-context-packets.md#autonomous-mode-contributor-packets),
explicit file ownership and exact source states. Avoid overlapping writes;
review the integrated candidate after concurrent implementation. A reviewer
who repairs work becomes its doer and needs another verifier for the affected
evidence. Preserve review findings and iterations rather than replacing an
unfavorable reviewer. Operator decisions and tool restrictions remain binding.
Before dispatch, apply the methodology's
[mandatory Operator model and expenditure selection](../../engineering-methods/guides/01-engineering-methodology.md#mandatory-operator-model-and-expenditure-selection).
Default to one implementer and one independent reviewer; extra contexts need a
named purpose, bounded ownership, return contract and exit condition within the
approved role/model, concurrency and expenditure scope. Defaults/inheritance do
not replace the Operator's answer. An unavailable choice or out-of-scope change
holds affected dispatch until resolved.

Give each mutable worktree one mutation owner and name the staging/integration
owner. Serialize installs, generation, edits and loaders/scanners whose inputs
can change; separate write paths alone do not make a shared tree stable. Parallel
mutable work needs isolated worktrees or justified noninterference. On handoff,
recheck actual revision/dirty inputs and preserve others' changes and outputs
of unknown ownership. Outside this exception, use the ordinary policy below.

## Core Policy

The [contributor workflows](../../engineering-methods/guides/01-engineering-methodology.md#roles-and-shared-invariants)
assign sustained responsibilities to Operator-selected contexts. They are not
ad hoc subagent delegation: each assigned contributor owns its judgment and
loads its governing plans and evidence. Enabling CRC does not permit it to
delegate acceptance or design to lookup workers. CRC/CDC design exchanges use
explicit reports and return directives relayed by the Operator; a lookup
summary does not substitute for either handoff. The rules below govern
subagents within a contributor's work, not the existence of CC or CRC.

Do not delegate thinking work to subagents. Thinking work includes:

- code edits;
- design decisions;
- architecture choices;
- reasoning about tradeoffs;
- choosing between options;
- writing prose for the codebase;
- judging whether a finding is real;
- planning a task's structure;
- evaluating whether something is correct.

Subagent delegation is fine for lookup work. Lookup work includes:

- searching for files or symbols;
- grepping across a codebase;
- fetching documentation;
- listing call sites of a function;
- reading a file the main context has not loaded yet;
- enumerating evidence without judging what the evidence means.

The line is the kind of task, not the existence of a subagent tool.

## Operating Rule

Serial on thinking, parallel on lookup.

Thinking tasks in a multi-step job run one at a time in the main context.
Lookup subagents or parallel tools may run in parallel inside a task when the
result can be independently inspected.

Quality beats elapsed time on the thinking path. Do not trade thinking quality
for wall-clock speed. On the lookup path, parallelism is useful when it returns
checkable evidence.

## Planning Phrase

When planning a task, make both sides explicit:

```text
I will do X thinking/edit/review work in this context; I may delegate Y lookup
if useful.
```

Do not forbid all subagent use; that wastes lookup parallelism. Do not leave the
line implicit; it will not hold under pressure.

## Why The Boundary Exists

Thinking delegation fails in four recurring ways:

1. **Context loss.** The subagent does not see the conversation. A
   self-contained prompt discards nuance.
2. **Skill loss.** Expert skills, style rules, and project conventions loaded
   in the main context do not automatically propagate.
3. **Brittle judgment prompts.** Asking a context-starved agent to make the
   right architectural call is usually harder than making the call directly.
4. **Integration friction.** The subagent returns a summary. The main context
   still has to evaluate whether the summary is right, whether to accept it,
   and whether to push back.

None of this applies to mechanical lookups where the answer is evidence the
parent context can inspect.

## Good Delegation Shapes

Good delegated work returns evidence:

- "Find every call site of `foo()`."
- "List files matching `crates/**/*.rs` that import `bar`."
- "Grep the repo for `TODO(perf)`."
- "Read these three files and report their headings and exported symbols."

Bad delegated work asks for judgment:

- "Implement this function."
- "Decide between these approaches."
- "Review this diff."
- "Design this schema."

## Caveat

This policy is calibrated for sustained, high-quality software engineering
work, where the cost of subtly wrong judgment compounds across the project. For
pure exploratory research, rapid prototyping, or tasks where elapsed time
matters more than depth, looser delegation may be acceptable, but that is a
different operating mode and must be named explicitly.

## Component History

The agent-coordination component history lives at
[`../version-history.md`](../version-history.md).
