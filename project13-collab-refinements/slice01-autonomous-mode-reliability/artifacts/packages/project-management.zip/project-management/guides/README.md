# Project Management Guides

> Wayfinder for the framework's project-management layer: the scales of work,
> planning artifacts and where they live on disk, the confirmation protocol,
> top-down planning, bottom-up close/bubble-up, and the maintenance discipline
> that keeps those mechanics from drifting.

This README is deliberately short. The operational detail used to live in one
long document; it is now split into focused files in this `guides/` directory.
Start here, choose the section that matches the job, and load only the detailed
files the job requires.

The companion [methodology](../../engineering-methods/guides/01-engineering-methodology.md) names the
philosophy: the three pillars, the 9-point SDLC, and the anti-degradation
disciplines. The project-management files are where that philosophy becomes
specific artifacts, filesystem layout, reports, and close checks. Do not
improvise those mechanics from the methodology summary.

## Notes for Codex

For Codex, read every "Claude session" in the linked files as any fresh Codex
Desktop, Codex CLI, or other LLM session entering the project without the full
prior context. For the canonical **CC**, **CDC**, **CRC**, and **Operator** role
definitions, read
[`01-engineering-methodology.md#notes-for-codex`](../../engineering-methods/guides/01-engineering-methodology.md#notes-for-codex).
Keep the canonical filenames (`project-plan.md`, `arc-plan.md`,
`slice-plan.md`, per-scale `ledger.md`, initial `cc-prompt.md`,
follow-up `cc-prompt-iterationNN.md`,
`closing-report.md`, and the workflow-specific verification records) and the
default slice `artifacts/` home unless the operator explicitly changes the project
convention. Existing `cdc-verification.md` records and project conventions
remain valid; follow the [verification filename compatibility rule](./02-canonical-planning-worktree.md#verification-filename-compatibility).

Default to the **Two-Contributor Workflow** (CDC + CC). Only explicit Operator
selection enables the **Three-Contributor Workflow** (CDC + CRC + CC), except
for CDC selections within explicitly authorized Autonomous Mode.
Read the methodology's [workflow sections](../../engineering-methods/guides/01-engineering-methodology.md#two-contributor-workflow)
before assigning roles or changing workflows. In these guides, the **assigned
reviewer** is CDC in the default workflow or CRC in the explicitly enabled
three-contributor workflow; an author of implementation cannot independently
accept that implementation. CRC prepares subsequent slices within the approved
arc; CDC retains project/arc design and first-slice preparation. Material plan
changes go through CDC and the Operator before affected work advances.

The Operator may explicitly select the **One-Contributor Workflow**, documented
after the two multi-contributor sections in the methodology. Do not create
planning artifacts solely to simulate multiple roles for a bounded task.
Existing ledgered work retains its artifact, evidence, and approval contract;
the sole contributor's self-checks do not count as independent acceptance.

At slice level, use `cdc-verification.md` for two contributors and
`crc-verification.md` for three. Three-contributor arc/project closure requires
both CRC and CDC records with different evidentiary responsibilities; read
[verification records by workflow and scale](./02-canonical-planning-worktree.md#verification-records-by-workflow-and-scale).

Three-contributor and Autonomous Mode closing activities also include CDC
[retrospectives at every scale](./02-canonical-planning-worktree.md#retrospective-records-in-the-three-contributor-workflow).
Load [methodology-stewardship](../../methodology-stewardship/guides/01-retrospectives-and-follow-through.md)
for analysis; a retrospective does not replace the verification records.

Issued prompts are preserved. Every follow-up assignment gets a new numbered
prompt in the slice root, beside the initial prompt; `artifacts/` holds
supporting outputs. Before issuing or executing a follow-up, load the layout
and iteration workflow below.

This wayfinder and the linked files guide planning craft and the quality floor;
they do not override Codex's standing system, developer, tool, safety, sandbox,
or user instructions. If a conflict appears, name the tension and follow the
governing instruction stack rather than forcing the methodology to fit.

## Required Load Set

If you are about to **plan or close anything** -- a project, an arc, or a slice
-- read this wayfinder first, then read the detailed file or files for the
operation at hand. For full project-management context, read the files below in
order.

| Job | Read |
| --- | --- |
| Understand the vocabulary and sizing model | [`guides/01-scales-of-work.md`](./01-scales-of-work.md) |
| Create or inspect planning directories, filenames, metadata, per-scale document sets, or slice artifact homes | [`guides/02-canonical-planning-worktree.md`](./02-canonical-planning-worktree.md) |
| Write a `project-plan.md`, `arc-plan.md`, per-scale `ledger.md`, or per-slice open set | [`guides/03-planning-top-down.md`](./03-planning-top-down.md) |
| Author or review initial or corrective CC implementation instructions | Engineering-methods [From Slice to Implementation Prompt](../../engineering-methods/guides/07-implementation-prompt-authoring.md), relevant domain guides and the actual implementation baseline; complete author readiness before issuing. |
| Issue, resume, or execute a slice iteration | [Iteration filenames and preservation](./02-canonical-planning-worktree.md#slice-iteration-filenames-and-preservation) and [issuing and executing an iteration](./03-planning-top-down.md#issuing-and-executing-an-iteration) |
| Escalate from CRC to CDC, or return CDC instructions to CRC through the Operator | [Design handoff filenames](./02-canonical-planning-worktree.md#design-handoff-filenames-and-preservation) and [design escalation and return handoffs](./03-planning-top-down.md#design-escalation-and-return-handoffs) |
| Close a slice and bubble findings up to the arc | [`guides/04-closing-slices.md`](./04-closing-slices.md) and [`guides/05-closing-arcs.md`](./05-closing-arcs.md#the-plan-change-discipline-make-a-change--version-history) |
| Close an arc, check composition, and bubble findings up to the project | [`guides/05-closing-arcs.md`](./05-closing-arcs.md) |
| Perform a three-contributor closing retrospective | [Record and handoff contract](./02-canonical-planning-worktree.md#retrospective-records-in-the-three-contributor-workflow), then [methodology-stewardship](../../methodology-stewardship/guides/01-retrospectives-and-follow-through.md). |
| Confirm a layout before creating planning directories or filenames | [`guides/06-confirmation-protocol.md`](./06-confirmation-protocol.md) |
| Detect or refuse recurring bad planning shapes | [`guides/07-anti-patterns.md`](./07-anti-patterns.md) |
| Update this project-management spec | [`guides/08-maintenance.md`](./08-maintenance.md) and [`version-history.md`](../version-history.md) |
| Ground the project-management flow in a real run | [`examples/01-worked-example-odm.md`](../examples/01-worked-example-odm.md) |

## Expedited Mode

For tighter, more temporally efficient implementation cycles, the operator may
opt into **Expedited Mode**. When engaged, the LLMs must adhere to the
following:

- Have CC commit after changes, even before the assigned reviewer's acceptance.
  Because other processes may be working on the same branch and staging their own files, CC
  commit instructions must explicitly list the files to be committed.
- Have the assigned reviewer commit after review or planning changes, and
  provide the operator with concise reports.
- As soon as the evidence is in place for a full close of a slice, close it.
- After a slice is closed, open the next slice immediately and give the
  operator the next CC prompt path as plain copy/paste text, not as a Markdown
  link. The path must be relative to the project directory and include the full
  arc/slice path, for example `arc02-example/slice01-example/cc-prompt.md`.
  Clickable file links may be included only in addition to the plain relative
  path, never instead of it.
- After the last slice of an arc is closed, automatically continue to formal
  arc close, then open the next arc and its first slice, complete with CC
  prompt, when the project roadmap provides one. Report that first slice's
  `cc-prompt.md` path in the same plain relative copy/paste form.

These responsibilities follow the selected workflow: CRC advances routine
slices when enabled, while CDC owns the next arc and its first slice. Automatic
advancement stops at unresolved escalations and independent or Operator gates;
it does not authorize CRC to open a new arc or change the agreed architecture.

Expedited Mode only changes the explicit commit, close, and advance behaviors
listed above. Expedited Mode means no shortcuts, no skipped validation, no
weaker evidence or review, no inferred source scope and no reduction or other
change in scope, no timeline interpretation, and no override of explicit
operator approval gates recorded in a plan or prompt.

Guardrail phrases for source and package validation: no shortcuts; no skipped validation; no weaker evidence or review; no inferred source scope and no reduction or other change in scope; no timeline interpretation; operator approval gates are not overridden.

## Autonomous Mode

When the Operator selects Autonomous Mode, first read its
[canonical definition](../../engineering-methods/guides/01-engineering-methodology.md#autonomous-mode).
It includes Expedited Mode and authorizes CDC to select and revise contributor
arrangements within the recorded scope. One-Contributor is limited to simple,
clearly defined, low-risk, low-effort tasks or slices, with recorded rationale
and proportionate self-checks; it cannot bypass review gates or unresolved
findings. Escalate staffing or pause when the work no longer fits that boundary.
Retrospectives remain mandatory in all three methods. The default endpoint is
the named arc;
an explicit override may authorize several arcs or a whole approved project.
At that endpoint, report back instead of following Expedited Mode's normal
next-arc advancement beyond the authorization.

Before starting, record the scope/endpoint, task source branch, planning worktree,
contributor assignments, independent verification convention and existing
Operator gates in the governing plan. Implementation must be on a dedicated
non-default branch. Explicitly ask the Operator for role/model/provider/settings
and expenditure/concurrency choices before Autonomous role work; record the
answer under the methodology's
[mandatory selection gate](../../engineering-methods/guides/01-engineering-methodology.md#mandatory-operator-model-and-expenditure-selection).
An inherited/default model is not approval. Default to one implementer and one
independent reviewer; justify extra contexts and respect the approved spend scope.
Include automatic pipeline effects in external-action authority before triggering
them. Keep the preflight compact, with complete contracts linked and changed
source/ownership facts revalidated after handoff or recovery.
Preserve scope and role transitions, durable prompts,
review/repair cycles and iteration limits. Routine contributor handoffs within
this authority can go directly between assigned contexts; preserve their
records and report decisions to the Operator without requiring human relay.
Explicit external-messaging permissions and tool restrictions still apply.
Decisions reserved to the Operator still go to the Operator.

Close and bubble up each slice, verify composition at arc/project scale, and
complete CDC retrospectives at every closing scale using the
[record contract](./02-canonical-planning-worktree.md#retrospective-records-in-the-three-contributor-workflow).
When new evidence makes a plan choice too ambiguous to resolve confidently,
pause affected work and surface the decision; record the resolution before
resuming dependent work. Report completed scope, validation, review findings,
commits and retrospective conclusions. Use the canonical
[evidence indexing and research-record contract](./02-canonical-planning-worktree.md#evidence-batches-and-research-records)
for durable original observations and derived current views; batch indexes do
not replace any ledger or independent/higher-scale acceptance record. Pending
independent or Operator gates remain pending even at the authorization endpoint.

## Split Files

The old monolith split along its original part boundaries:

1. [`guides/01-scales-of-work.md`](./01-scales-of-work.md) -- project, arc,
   slice, step, iteration, sizing, and the context-window basis for a slice.
2. [`guides/02-canonical-planning-worktree.md`](./02-canonical-planning-worktree.md)
   -- default planning worktree, `planning` branch, `projectNN-<slug>`,
   metadata, naming rules, dedicated project/arc/slice ledger files, and the
   per-slice document set plus the default slice `artifacts/` home.
3. [`guides/03-planning-top-down.md`](./03-planning-top-down.md) -- project
   roadmaps, arc plans, per-slice open sets, and plan-late/plan-deep.
4. [`guides/04-closing-slices.md`](./04-closing-slices.md) -- slice
   `closing-report.md`, the workflow-specific verification record,
   and slice-to-arc bubble-up.
5. [`guides/05-closing-arcs.md`](./05-closing-arcs.md) -- arc
   `closing-report.md`, composition checks, arc-to-project bubble-up, and the
   plan-change discipline.
6. [`guides/06-confirmation-protocol.md`](./06-confirmation-protocol.md) -- when
   to confirm, how to ask, and what to record after the operator answers.
7. [`guides/07-anti-patterns.md`](./07-anti-patterns.md) -- planning layouts and
   habits to refuse or surface before adopting.
8. [`guides/08-maintenance.md`](./08-maintenance.md) -- when to update the spec
   itself.
9. [`examples/01-worked-example-odm.md`](../examples/01-worked-example-odm.md) -- a concrete
   example of the project-management flow.
10. [`version-history.md`](../version-history.md) -- version history for
    the project-management skill.

## Minimum Context Shortcuts

Use these only when context is tight and the operation is narrow:

- **Starting a new planning layout:** read
  [`guides/02-canonical-planning-worktree.md`](./02-canonical-planning-worktree.md)
  and [`guides/06-confirmation-protocol.md`](./06-confirmation-protocol.md).
- **Planning an active arc or slice:** read
  [`guides/01-scales-of-work.md`](./01-scales-of-work.md),
  [`guides/02-canonical-planning-worktree.md`](./02-canonical-planning-worktree.md),
  and [`guides/03-planning-top-down.md`](./03-planning-top-down.md). When writing
  implementation instructions, also read the [prompt-authoring guide](../../engineering-methods/guides/07-implementation-prompt-authoring.md).
- **Closing a slice:** read
  [`guides/04-closing-slices.md`](./04-closing-slices.md) and the plan-change
  discipline in
  [`guides/05-closing-arcs.md`](./05-closing-arcs.md#the-plan-change-discipline-make-a-change--version-history).
- **Closing an arc:** read [`guides/05-closing-arcs.md`](./05-closing-arcs.md).
- **Returning a slice to CC or resuming a refinement pass:** read the
  iteration filename contract in
  [`guides/02-canonical-planning-worktree.md`](./02-canonical-planning-worktree.md#slice-iteration-filenames-and-preservation)
  and the handoff workflow in
  [`guides/03-planning-top-down.md`](./03-planning-top-down.md#issuing-and-executing-an-iteration).

When in doubt, prefer reading the split files in order. The split reduces
context load; it does not relax the requirement to use the written mechanics.

The skill change record lives in [version-history.md](../version-history.md).
