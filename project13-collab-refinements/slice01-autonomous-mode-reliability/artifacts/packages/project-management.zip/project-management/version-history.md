# Version History

## Version 3.0.0 - 2026-10-19

Apply the mandatory Operator model/expenditure gate in Autonomous execution and contributor records. Define durable evidence batches as indexes into existing canonical artifact homes, never replacement acceptance units: preserve original failed/successful and independent observations, derive mechanical facts with provenance, retain requested/observed settings and protect long-term reconstruction. Preserve all issued prompts, per-scale ledgers and historical records. The required selection gate changes the prior execution contract.

## Version 2.20.0 - 2026-10-18

Added Autonomous Mode execution and authorization boundaries to Expedited Mode
operations; preserved durable handoffs, reviewer attribution, scale-specific
gates and mandatory CDC retrospectives across contributor arrangements.

Clarified the limited One-Contributor option for simple, clearly defined,
low-risk, low-effort work. Retained mandatory retrospectives in every method,
existing independent gates and escalation when complexity or risk increases;
prohibited using the exception to evade review or unresolved findings.

## Version 2.19.1 - 2026-10-12

Refined new-project decomposition around usable increments, scoped prerequisite
inputs, positive preservation and explicit integration states. Clarified that
project planning establishes architecture while the project delivers its promised
result; supporting artifacts do not replace source or product delivery. Bounded
investigation-only work by its decision consumer and stop/re-entry conditions.
Connected closing evidence to usable outcomes and incremental composition checks.
Required prior Operator discussion and agreement on investigation usefulness,
applicability and budget, including embedded inquiries and extensions; a proposal
or a "bounded" label is not authorization. These refinements carry forward the
Operator-endorsed Project11 planning changes and subsequent investigation decision;
they add no document layer and make no measured efficiency claim. Existing scope,
independent review, iteration limits and release gates remain in force.

## Version 2.19.0 - 2026-10-12

Added the three-contributor CDC retrospective record at every closing scale,
Operator-relayed handoff, explicit pending/completed responsibility, and routes
to methodology-stewardship. Kept learning records separate from acceptance and
preserved existing workflow gates, history and filename overrides.

## Version 2.18.1 - 2026-09-28

Aligned slice closing with work-verification's correction-review rule. Review
accounts for every row, reproduces new and affected claims, and explicitly
assesses applicability of retained independent evidence. Bubble-up, assignment
preservation, bookkeeping and Operator gates remain unchanged.

## Version 2.18.0 - 2026-09-17

Routed initial and iterative CC execution through the complete-reading and
intake contract. Issued prompts specify reading scope and an allowed record home;
CC captures coverage and a contract readback before dependent edits. Review uses
actual sources and behavior; the preflight adds no Operator approval gate.

## Version 2.17.0 - 2026-09-17

Added the explicit handoff from slice planning to engineering-methods prompt
authorship. Initial and corrective implementation assignments require the
source-grounded design, applied domain guidance, implementation recipe and
readiness check before issue. Existing artifact, preservation, workflow and
Operator-gate contracts remain unchanged.

## Version 2.16.0 - 2026-09-17

Mapped planning, iteration, closure, and Expedited Mode to the selected
contributor workflow without enabling CRC implicitly. Added preserved
`crc-escalationNN.md` and `cdc-directiveNN.md` packets, Operator relay in both
directions, explicit decisions, and acknowledgement/history requirements.
Defined slice `cdc-verification.md` for two contributors and
`crc-verification.md` for three, with paired CRC/CDC records at arc/project
scale in the three-contributor workflow. Preserved historical filenames and
required explicit active-record lineage on transitions. Plan maintenance and
automatic advancement cannot bypass architectural escalation or approval gates.
Distinguished one-contributor bounded tasks from existing ledgered work so
workflow selection does not manufacture planning artifacts or erase gates.

## Version 2.15.0 - 2026-09-14

Defined preserved, distinct slice-root prompts for successive CC assignments:
initial `cc-prompt.md`, then `cc-prompt-iterationNN.md`. Distinguished
first-class slice documents from supporting `artifacts/` outputs. Added the
assignment-history record, explicit CDC-to-CC handoff and execution requirements,
and close/review traceability across attempts. Covered legacy-path disposition,
unstarted prompt replacements, the existing iteration budget, and recurring
prompt-reuse, artifact-placement, and premature-return anti-patterns. Updated
entrypoint discovery, wayfinding, layout examples, and confirmation guidance.

## Version 2.14.0 - 2026-09-06

Placed the skill version inside entrypoint metadata for compatibility with the skill-creator frontmatter validator.

Unified the skill and former local-document version sequences at 2.14.0, the highest existing version (with omitted components normalized to zero). The entrypoint is now the sole current-version authority; the original records below retain their provenance and are retired as independent sequences. Removed the guide README version labels and inline release summary.

## Retired Version Sequences

### Version 2.14 - September 2026

Clarified the Expedited Mode handoff rule after slice close: when opening the
next slice, report the CC prompt path as plain copy/paste text, not as a
Markdown link. The path must be relative to the project directory and include
the full arc/slice path, with clickable file links allowed only as additional
convenience.

### Version 2.13 - September 2026

Updated the component entrypoint to reflect that project-management now ships
both inside `collaboration-framework.zip` and as standalone
`project-management.zip`.

### Version 2.12 - September 2026

Renamed the project-management guide-set wayfinder from
`guides/PROJECT-MANAGEMENT.md` to `guides/README.md`, matching its role as the
index and required-load router for the numbered project-management guides.
Updated live source, package, and release-note routes so `README.md` is the
current load target and the old path is no longer live.

### Version 2.11 - September 2026

Updated the maintenance guide's CAP-style audit cross-reference to the split
code-auditing guide surface. Audit output homes now route through
`code-auditing/guides/01-audit-scope-and-map.md`; the former CODE-AUDIT path is
historical lineage only.

### Version 2.10 — September 2026

Updated project-management guide links to the split work-verification guide
surface. Ledger-discipline overview routes now point to the primary
work-verification guide, while row-close mechanics route to the focused row
closure guide. The retained ledger template remains available as a support
asset through the work-verification component.

### Version 2.9 — September 2026

Moved the worked example from `guides/09-worked-example-odm.md` to
`examples/01-worked-example-odm.md`, matching the accepted Project04 Arc08
project-management layout. The eight numbered project-management guides and
the guide-set wayfinder remained under `guides/`.

### Version 2.8 — September 2026

Moved project-management version history from `guides/version-history.md` to
the sibling component file `version-history.md`, matching the framework
component history rule: the component version remains in `SKILL.md`, while
changes to `SKILL.md`, `guides/`, `templates/`, or `examples/` are recorded in
the sibling history file. Updated local routes and package lists for the move.

Clarified **Expedited Mode** in the project-management wayfinder: it only
changes the explicit listed commit, close, and advance behaviors. It means no
shortcuts, no skipped validation, no weaker evidence or review, no inferred
source scope and no reduction or other change in scope, no timeline
interpretation, and no override of explicit operator approval gates.

Documented the framework component version-history management practice in the
top-level AGENTS file so future source-edit sessions see the rule before
changing framework component files.

### Version 2.7 — September 2026

Routed CC, CDC, and Operator terminology to
[`../engineering-methods/guides/01-engineering-methodology.md#notes-for-codex`](../engineering-methods/guides/01-engineering-methodology.md#notes-for-codex)
as the current collaboration-framework source of truth. The
project-management wayfinder now avoids carrying partial local definitions
while preserving canonical filenames, artifact homes, and Expedited Mode
behavior.

### Version 2.6 — September 2026

Added **Expedited Mode** to the project-management wayfinder. When the
operator asks for this mode, CC commits the explicit file list after his close
packet, CDC commits verification and planning updates separately, slices close
as soon as evidence is reproduced, the next slice opens immediately after
slice close, and final-slice closure proceeds through formal arc close before
opening the next roadmap-provided arc and first slice.

This is a speed mode, not a weaker verification mode: it keeps explicit commit
scope, CDC reproduction of evidence, bottom-up slice/arc closure, and
operator-visible reports.

### Version 2.5 — August 2026

Added `sliceNN-<slug>/artifacts/` as the default home for durable artifacts
produced by a slice. The operator can override the location, but the override
must be explicit in `slice-plan.md`, repeated in `cc-prompt.md`, and verified at
slice close through the artifact inventory in `closing-report.md` and
`cdc-verification.md`.

Updated the canonical planning-worktree tree, top-down planning rules, slice
closing rules, confirmation-protocol example, anti-pattern list, and maintenance
notes. The change distinguishes the five per-slice Markdown documents from
slice-produced work artifacts so planning records and output evidence do not
compete for the same term.

### Version 2.4 — August 2026

Changed the canonical ledger layout so **every scale gets a dedicated
`ledger.md` file**. Project ledgers now live beside `project-plan.md`, arc
ledgers live beside `arc-plan.md`, and slice ledgers continue to live beside
`slice-plan.md`. This replaces the v2.1 transitional "ledger section inside the
plan file" arrangement for projects and arcs.

Updated the canonical planning-worktree tree, top-down planning rules,
confirmation-protocol example, and anti-pattern list to keep plan files focused
on scope/sequencing while ledger files carry acceptance and composition rows.

### Version 2.3 — August 2026

Split the long project-management monolith into focused files under `guides/`,
preserving the original part boundaries. The guide-set wayfinder has a required
load set, a split-file index, and minimum-context shortcuts for common
operations. This keeps the wayfinder as the entry point while reducing the
context load for LLM sessions that only need one piece of the
project-management discipline.

- Refreshed the worked example after the v2.3 split so it teaches the general
  project-management flow rather than documenting the `odm` tool itself.

### Version 2.2 — August 2026

Changed the default project-planning substrate from an implementation-branch
`docs/design-vX.Y.Z` tree to a dedicated orphan `planning` branch mounted as a
Git worktree. The default project directory now follows the same convention as
arcs and slices: `projectNN-<slug>`. Added the planning worktree discovery and
creation rules, the `projectNN-<slug>` naming rule, project metadata fields for
`depends-on` / `blocks` / `related`, and confirmation-protocol language that
records the chosen planning branch, worktree, and project directory in local
instructions. Also renamed the slice plan-of-record from `slice-doc.md` to
`slice-plan.md`, matching `project-plan.md` and `arc-plan.md`.

This rev was catalysed by the `dns` / `vault` split planning work: the old
`docs/design-v0.1.0` default repeatedly caused humans and LLMs to confuse
planning scope with release scope and to reuse product-documentation trees for
planning records. The new default makes planning docs their own branch-backed
source of truth, while project metadata carries ordering and relationship
semantics.

### Version 2.1 — June 2026

Synchronised with `LEDGER-DISCIPLINE.md` v2.0, which extended ledger discipline
from slice-only to all three scales. Added the **ledger section** to the
required contents of `arc-plan.md` (the arc ledger's composition rows, Part III)
and `project-plan.md` (the project ledger's DoD rows, Part III); noted in the
canonical planning worktree (Part II) that the arc and project ledgers live as
sections in those plan docs and close in the matching `closing-report.md`
(Option A — no new files); and tied the arc composition check (Part V) to the
arc/project ledger closure. This embedded-section layout was superseded by
v2.4, which gives every scale its own sibling `ledger.md`. The
bubble-up/close machinery is unchanged; this rev names the
verification rigor that now backs it at each scale.

### Version 2.0 — June 2026

Renamed from `ASSET-ORGANISATION.md` (v1, which covered only the slice/arc
layout and the confirmation protocol) and substantially expanded into the
framework's full project-management home. v1's scope note had **deferred**
project- and epic-level organisation "pending in-flight work on epic- and
project-level dependency tracking" — that work is the `odm` rebuild, which has
now matured through three arcs and informs this revision. v2.0 lands the
deferred layer:

- **Absorbed the scales-of-work, fundamental-unit, sizing, and default-layout
  detail extracted from [`01-engineering-methodology.md`](../engineering-methods/guides/01-engineering-methodology.md)**
  (which now keeps a summary and points here). The vocabulary
  (project/arc/slice/step/iteration) and the context-window basis for sizing a
  slice now live in Part I; the canonical planning worktree in Part II.
- **Added `project-plan.md`** as the project-level plan-of-record (the arc
  roadmap), and formalized `arc-plan.md`'s required contents (Part III).
- **Added the top-down / bottom-up framing** and *plan late, plan deep*
  (Part III).
- **Added the slice bubble-up report and check** (Part IV), including the
  explicit slice-close arc-plan-update step, carried in the existing
  `closing-report.md` / `cdc-verification.md` rather than new files.
- **Added the formal arc-close process** (Part V): an arc-level
  `closing-report.md`, the composition check, the arc bubble-up report and
  check, and the project-plan-update decision it forces.
- **Added the plan-change discipline** (make-a-change + version-history,
  Part V) generalizing spec-keeping to the plan documents themselves.
- **Extended the anti-patterns** (Part VII) with closing-without-bubbling-up,
  closing-an-arc-by-fiat, never-changing plans, and far-ahead detailed plans.
- **Added a worked example** (Part IX, the `odm` rebuild).

The confirmation protocol (Part VI) and the anti-pattern core (Part VII) carry
forward from v1 with the layout references updated to this file and to the new
`project-plan.md` / arc-close artifacts.

### Version 1 — June 2026 (as `ASSET-ORGANISATION.md`)

Established the operational companion to the methodology's *A default layout*:
the slice/arc tree, the five per-slice documents, and the **confirmation
protocol** (quote the default, name the substitutions, give the operator
proceed / adjust / override, record the choice in the project's `CLAUDE.md`).
Broader project- and epic-level organisation was deferred. Shipped bundled in
the `collaboration-framework` skill.

---
